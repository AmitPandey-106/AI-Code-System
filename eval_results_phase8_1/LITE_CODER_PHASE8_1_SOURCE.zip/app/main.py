import ast
from fastapi import FastAPI
from pydantic import BaseModel

from app.model import generate_code, fix_code, classify_error
from app.executor import execute_code
from app.feedback import save_feedback
from app.tester import run_tests
from app.repair_memory import repair_memory
from app.repair_difficulty import estimate_difficulty
from app.strategy_selector import strategy_selector
from app.repair_strategy import get_strategy_prompt
from app.config import config

app = FastAPI()

from fastapi.middleware.cors import CORSMiddleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =========================================================
# REQUEST MODEL
# =========================================================

from typing import List, Optional, Any
from pydantic import Field

class Request(BaseModel):
    prompt: str
    authoritative_tests: List[str] = Field(default_factory=list)
    experiment_id: Optional[str] = None
    task_id: Optional[str] = None
    task_index: Optional[int] = None
    approved_plan: Optional[str] = None

class PlanRequest(BaseModel):
    prompt: str
    feedback: Optional[str] = None
    authoritative_tests: List[str] = Field(default_factory=list)

def infer_initial_tests(prompt: str, contract: Optional[Any] = None) -> List[str]:
    """Safely infer default test assertions for standard benchmark tasks only when explicitly defined."""
    if contract is None:
        from app.contract import TaskContract
        contract = TaskContract.create_from_prompt(prompt)
    fn = contract.entry_point
    if not fn:
        return []

    lower_fn = fn.lower()
    lower_prompt = prompt.lower()
    params = contract.parameters
    p_len = len(params)

    num_args = p_len
    if any(k in lower_prompt for k in ["three", " 3 ", "3 number", "three number", "3 args", "three args"]):
        num_args = 3
    elif any(k in lower_prompt for k in ["four", " 4 ", "4 number", "four number"]):
        num_args = 4

    if "binary_search" in lower_fn:
        return [
            f"assert {fn}([1, 2, 3, 4, 5], 3) == 2 or {fn}([1, 2, 3, 4, 5], 3) is True",
            f"assert {fn}([10, 20, 30], 25) == -1 or {fn}([10, 20, 30], 25) is False"
        ]
    elif lower_fn in ("add", "sum"):
        if num_args == 3:
            return [f"assert {fn}(1, 2, 3) == 6", f"assert {fn}(10, 20, 30) == 60"]
        elif num_args == 4:
            return [f"assert {fn}(1, 2, 3, 4) == 10", f"assert {fn}(5, 5, 5, 5) == 20"]
        elif num_args == 2:
            return [f"assert {fn}(2, 3) == 5", f"assert {fn}(-1, 1) == 0"]
        return [f"assert {fn}([1, 2, 3]) == 6", f"assert {fn}([0]) == 0"]
    elif "concat" in lower_fn:
        return [f"assert {fn}('Hello ', 'World') == 'Hello World'", f"assert {fn}('Lite', 'Coder') == 'LiteCoder'"]
    elif "fib" in lower_fn:
        if any(k in lower_prompt for k in ["seq", "series", "list", "array", "first", "terms", "numbers"]):
            return [
                f"assert {fn}(0) in (0, [], [0])",
                f"assert {fn}(1) in (1, [0], [1], [0, 1])",
                f"assert {fn}(5) == 5 or {fn}(5) == [0, 1, 1, 2, 3] or {fn}(5) == [0, 1, 1, 2, 3, 5] or (isinstance({fn}(5), (list, tuple)) and len({fn}(5)) in (5, 6))"
            ]
        return [
            f"assert {fn}(0) in (0, [], [0]) or {fn}(0) == 0",
            f"assert {fn}(1) in (1, [0], [1], [0, 1]) or {fn}(1) == 1",
            f"assert {fn}(5) == 5 or (isinstance({fn}(5), (list, tuple)) and (5 in {fn}(5) or len({fn}(5)) in (5, 6)))"
        ]
    elif "factorial" in lower_fn:
        return [f"assert {fn}(0) == 1", f"assert {fn}(4) == 24"]
    elif "palindrome" in lower_fn:
        return [f"assert {fn}('radar') is True", f"assert {fn}('hello') is False"]
    elif "reverse" in lower_fn:
        return [f"assert {fn}('hello') == 'olleh'", f"assert {fn}('') == ''"]
    elif "even" in lower_fn:
        return [f"assert {fn}(4) is True", f"assert {fn}(7) is False"]

    # For custom or non-standard entry points, do not invent dummy asserts
    return []

# =========================================================
# HOME & PLAN ROUTES
# =========================================================

@app.get("/")
def home():
    return {
        "message": "AI Code Generator Running 🚀"
    }

class NativeTestRequest(BaseModel):
    repo_root: str
    command: str
    timeout: Optional[int] = 30

@app.post("/run_native_tests")
def run_native_tests(req: NativeTestRequest):
    from app.project_test_runner import project_test_runner
    result = project_test_runner.run_tests(req.repo_root, req.command, req.timeout)
    return result

class PatchRequest(BaseModel):
    repo_root: str
    diff_text: str
    expected_patch_hash: Optional[str] = None
    expected_hashes: Optional[dict[str, str]] = None

@app.post("/propose_patch")
def propose_patch(req: PatchRequest):
    from app.patch_engine import PatchEngine
    engine = PatchEngine(req.repo_root)
    result = engine.apply_patch(req.diff_text, dry_run=True)
    if result["success"]:
        import hashlib
        result["patch_hash"] = hashlib.sha256(req.diff_text.encode()).hexdigest()
    return result

@app.post("/apply_patch")
def apply_patch(req: PatchRequest):
    from app.patch_engine import PatchEngine
    engine = PatchEngine(req.repo_root)
    import hashlib
    import uuid
    from fastapi import HTTPException
    from app.file_transaction import RepositoryLease
    if req.expected_patch_hash != hashlib.sha256(req.diff_text.encode()).hexdigest() or req.expected_hashes is None:
        raise HTTPException(409, "Apply requires the reviewed patch hash and source snapshot hashes from propose_patch")
    lease = RepositoryLease(req.repo_root, str(uuid.uuid4()))
    if not lease.acquire():
        raise HTTPException(409, "Repository has an active engineering transaction")
    try:
        return engine.apply_patch(req.diff_text, dry_run=False, expected_hashes=req.expected_hashes)
    finally:
        lease.release()

from app.engineering_api import router as engineering_router
app.include_router(engineering_router)

@app.post("/search")
def search_repo(query: str, top_k: int = 5):
    from app.repo_index import get_repo_indexer
    indexer = get_repo_indexer()
    results = indexer.search(query, top_k=top_k)
    return {"success": True, "results": results}

@app.post("/index")
def index_repo():
    from app.repo_index import get_repo_indexer
    indexer = get_repo_indexer()
    indexer.scan_and_index()
    return {"success": True, "message": "Repository indexed."}

@app.post("/plan")
def plan(req: PlanRequest):
    from app.model import generate_plan
    from app.contract import TaskContract
    from app.repo_index import get_repo_indexer
    
    task_prompt = req.prompt
    if req.feedback:
        task_prompt = f"{req.prompt}\n\nUSER FEEDBACK / REVISION REQUIREMENTS:\n{req.feedback}"
        
    indexer = get_repo_indexer()
    results = indexer.search(req.prompt, top_k=3)
    repo_context = ""
    if results:
        repo_context = "REPOSITORY CONTEXT:\n"
        for r in results:
            repo_context += f"File: {r['rel_path']} (Type: {r['type']})\n{r['snippet']}\n\n"
        task_prompt = f"{repo_context}\n{task_prompt}"

    contract = TaskContract.create_from_prompt(task_prompt, authoritative_tests=req.authoritative_tests)
    plan_text = generate_plan(task_prompt, contract=contract)
    
    # Infer matching tests using combined prompt and feedback
    combined_prompt = f"{req.prompt} {req.feedback or ''}"
    inferred = infer_initial_tests(combined_prompt)

    if req.feedback:
        # User gave explicit feedback (e.g. "for assert add three number")
        suggested_tests = inferred if inferred else req.authoritative_tests
    else:
        suggested_tests = req.authoritative_tests if req.authoritative_tests else inferred

    return {
        "success": True,
        "plan": plan_text,
        "suggested_tests": suggested_tests,
        "task_prompt": task_prompt,
        "entry_point": contract.entry_point,
        "parameters": contract.parameters
    }


# =========================================================
# MAIN GENERATION ROUTE
# =========================================================

import time
import uuid

def record_strategy_outcomes(feedback_record):
    """Update strategy policy using the fully verified outcomes (pass or fail)."""
    attempts = feedback_record.get("attempts", [])
    for i, att in enumerate(attempts):
        strat = att.get("strategy")
        if not strat:
            continue
            
        strategy_id = strat["selected_strategy"]
        error_type = att.get("error_type", "Unknown")
        attempt_num = att.get("attempt_number", 1)
        
        # The strategy generated a repair evaluated in the NEXT attempt.
        this_attempt_succeeded = False
        execution_passed = False
        tests_passed = False
        sec_viol = False
        t_out = False
        
        if i + 1 < len(attempts):
            next_att = attempts[i + 1]
            execution_passed = (next_att.get("execution_status") == "success")
            tests_passed = (next_att.get("test_results") or {}).get("success", False)
            this_attempt_succeeded = (execution_passed and tests_passed)
            next_err = next_att.get("error_type") or ""
            sec_viol = "SecurityViolation" in next_err
            t_out = "TimeoutError" in next_err
        
        strategy_selector.record_outcome(
            strategy_id=strategy_id,
            error_type=error_type,
            task=feedback_record["task"],
            attempt_number=attempt_num,
            success=this_attempt_succeeded,
            tests_passed=tests_passed,
            execution_passed=execution_passed,
            duration_ms=feedback_record.get("execution", {}).get("duration_ms", 500),
            feedback_id=feedback_record["feedback_id"],
            security_violation=sec_viol,
            timeout=t_out
        )

@app.post("/generate")
def generate(req: Request):
    from app.model import check_and_reload_adapter
    check_and_reload_adapter()

    MAX_RETRIES = 5
    start_time = time.time()
    feedback_id = uuid.uuid4().hex

    # Initialize structured feedback record
    feedback_record = {
        "feedback_id": feedback_id,
        "timestamp": start_time,
        "task": req.prompt,
        "initial_code": "",
        "attempts": [],
        "final_code": "",
        "final_status": "failure",
        "total_attempts": 0,
        "total_repairs": 0,
        "verification": {
            "syntax_passed": False,
            "safety_passed": False,
            "execution_passed": False,
            "tests_passed": False,
            "sandboxed_execution": True
        },
        "execution": {
            "status": "pending",
            "duration_ms": 0,
            "timeout": False
        },
        "security": {
            "status": "allowed",
            "violations": []
        },
        "execution_time": 0.0
    }

    from app import model as app_model
    app_model.check_and_reload_adapter()
    feedback_record["task_id"] = getattr(req, "task_id", None)
    feedback_record["task_index"] = getattr(req, "task_index", None)
    feedback_record["lora_enabled"] = config.get("LORA_ENABLED", False)
    feedback_record["active_adapter_id"] = app_model._loaded_adapter_id
    feedback_record["training_triggered"] = False
    feedback_record["training_cycle_id"] = None
    feedback_record["training_status"] = None

    # =====================================================
    # STEP 0: INITIALIZE TASK CONTRACT
    # =====================================================

    from app.contract import TaskContract, validate_code_against_contract
    contract = TaskContract.create_from_prompt(req.prompt, authoritative_tests=req.authoritative_tests)
    feedback_record["contract"] = {
        "entry_point": contract.entry_point,
        "parameters": contract.parameters,
        "requirements_count": len(contract.requirements)
    }

    # =====================================================
    # STEP 1: INITIAL CODE GENERATION
    # =====================================================

    current_code, prompt_text = generate_code(req.prompt, approved_plan=getattr(req, "approved_plan", None), contract=contract)
    
    # CONTROLLED DEFECT INJECTION ONLY FOR PROOF EXPERIMENT
    if req.experiment_id == "CONTROLLED_LORA_PROOF/STAGE2_TRAINING":
        original_code = current_code
        
        def safe_replace(code, old, new):
            lines = code.split("\n")
            for i in range(len(lines)-1, -1, -1):
                if old in lines[i]:
                    if "def " in lines[i]:
                        parts = lines[i].split(":", 1)
                        if len(parts) == 2 and old in parts[1]:
                            lines[i] = parts[0] + ":" + parts[1].replace(old, new, 1)
                            break
                    else:
                        lines[i] = lines[i].replace(old, new, 1)
                        break
            return "\n".join(lines)

        if str(req.task_id).strip() == "PROOF_T10":
            current_code = safe_replace(current_code, "> 0", "< 0")
            if current_code == original_code:
                current_code = safe_replace(current_code, ">", "<")
        elif str(req.task_id).strip() == "PROOF_T1":
            current_code = safe_replace(current_code, "+", "-")
        elif str(req.task_id).strip() == "PROOF_T2":
            current_code = safe_replace(current_code, "*", "/")
        elif str(req.task_id).strip() == "PROOF_T3":
            current_code = safe_replace(current_code, "[0]", "[-1]")
        elif str(req.task_id).strip() == "PROOF_T4":
            current_code = safe_replace(current_code, "<", ">")
        elif str(req.task_id).strip() == "PROOF_T5":
            current_code = safe_replace(current_code, "==", "!=")
        elif str(req.task_id).strip() == "PROOF_T6":
            current_code = safe_replace(current_code, "== 0", "== 1")
        elif str(req.task_id).strip() == "PROOF_T7":
            current_code = safe_replace(current_code, "-", "+")
        elif str(req.task_id).strip() == "PROOF_T8":
            current_code = safe_replace(current_code, "/", "*")
        elif str(req.task_id).strip() == "PROOF_T9":
            current_code = safe_replace(current_code, "[-1]", "[0]")
            
        print(f"\n[CONTROLLED DEFECT] Task: {req.task_id}")
        print(f"[CONTROLLED DEFECT] Original generated code: {original_code.strip()}")
        mutation_applied = (original_code != current_code)
        
        if not mutation_applied:
            print(f"[CONTROLLED DEFECT] mutation failed for {req.task_id}")
        else:
            print(f"[CONTROLLED DEFECT] Code after defect injection: {current_code.strip()}")
            
        # Record mutation state for forensic evidence
        feedback_record["controlled_mutation"] = {
            "applied": mutation_applied,
            "original_code": original_code,
            "mutated_code": current_code
        }

    feedback_record["initial_code"] = current_code
    feedback_record["generation_prompt"] = prompt_text

    # =====================================================
    # STEP 2: EMPTY GENERATION CHECK
    # =====================================================

    if not current_code or not current_code.strip():
        feedback_record["execution_time"] = time.time() - start_time
        save_feedback(feedback_record, experiment_id=req.experiment_id)
        return {
            "success": False,
            "message": "Model returned empty code",
            "attempts_used": 0,
            "feedback_record": feedback_record
        }

    attempt_history = []
    best_candidate = {
        "code": None,
        "tests_passed": -1,
        "total_tests": 0,
        "contract_valid": False,
        "execution_passed": False
    }

    # =====================================================
    # STEP 3: AUTONOMOUS RETRY LOOP
    # =====================================================

    for attempt in range(MAX_RETRIES):
        print(f"\n========== ATTEMPT {attempt + 1} ==========\n")
        feedback_record["total_attempts"] = attempt + 1
        
        attempt_record = {
            "attempt_number": attempt + 1,
            "code": current_code,
            "execution_status": "pending",
            "error_type": None,
            "error_message": None,
            "tests_generated": "",
            "test_results": None,
            "repair_applied": None,
            "verification": {},
            "contract_valid": True,
            "contract_error": None
        }

        # =================================================
        # CONTRACT VALIDATION
        # =================================================

        contract_valid, contract_err = validate_code_against_contract(current_code, contract)
        attempt_record["contract_valid"] = contract_valid
        attempt_record["contract_error"] = contract_err

        if not contract_valid:
            error = contract_err
            category, specific_type, specific_msg = classify_error(error)
            
            attempt_record["execution_status"] = "failed"
            attempt_record["error_type"] = "ContractViolation"
            attempt_record["error_message"] = contract_err

            # Retrieve Memory
            if config.get("MEMORY_ENABLED"):
                memories = repair_memory.search_similar_experiences(req.prompt, "ContractViolation", contract_err, current_code)
            else:
                memories = []
            memory_context = ""
            attempt_record["memory_used"] = len(memories) > 0
            attempt_record["retrieved_memory_count"] = len(memories)
            attempt_record["retrieved_memories"] = [{"memory_id": m["memory"]["memory_id"], "similarity": m["similarity"]} for m in memories]
            
            prev_strats = [att.get("strategy", {}).get("selected_strategy") for att in feedback_record["attempts"] if att.get("strategy")]
            diff_info = estimate_difficulty("ContractViolation", current_code, attempt + 1, len(memories) > 0)
            attempt_record["difficulty"] = diff_info
            
            strat_info = strategy_selector.select_strategy(
                error_type="ContractViolation",
                attempt_number=attempt + 1,
                previous_strategies=prev_strats,
                memory_available=len(memories) > 0,
                difficulty=diff_info["difficulty"]
            )
            attempt_record["strategy"] = strat_info
            
            if strat_info["selected_strategy"] not in ("DIRECT_REPAIR", "MINIMAL_PATCH") and memories:
                for idx, m in enumerate(memories):
                    memory_context += f"Experience {idx+1}:\nError:\n{m['memory']['error_message']}\nBroken Code:\n{m['memory']['broken_code']}\nSuccessful Fix:\n{m['memory']['successful_fix']}\n\n"

            attempt_record["memory_injected"] = len(memory_context) > 0
            
            attempt_history.append({
                "attempt": attempt + 1,
                "stage": "contract",
                "error_type": "ContractViolation",
                "error": contract_err
            })
            feedback_record["attempts"].append(attempt_record)

            print("\nContract Validation Failed:")
            print(contract_err)

            strat_prompt = get_strategy_prompt(strat_info["selected_strategy"])
            fixed_code, debug_prompt = fix_code(
                current_code, error, memory_context,
                strategy_prompt=strat_prompt,
                task_contract=contract,
                attempt_history=attempt_history
            )
            attempt_record["debug_prompt"] = debug_prompt
            attempt_record["repair_applied"] = fixed_code
            
            if not fixed_code or not fixed_code.strip():
                attempt_record["repair_generation_failed"] = True
                attempt_record["repair_failure_reason"] = "Model failed to produce valid Python code"
                attempt_record["repair_changed_code"] = False
            else:
                attempt_record["repair_generation_failed"] = False
                attempt_record["repair_failure_reason"] = None
                attempt_record["repair_changed_code"] = (fixed_code.strip() != current_code.strip())
                current_code = fixed_code
                
            feedback_record["total_repairs"] += 1
            if attempt + 1 >= MAX_RETRIES:
                print(f"\nMax retries exhausted ({MAX_RETRIES} attempts).")
                break
            continue

        # =================================================
        # EXECUTE CODE
        # =================================================
        
        start_exec = time.time()
        execution = execute_code(current_code, contract=contract)
        exec_duration = int((time.time() - start_exec) * 1000)
        feedback_record["execution"]["duration_ms"] = exec_duration

        # Store static verification data
        verif = execution.get("verification", {})
        attempt_record["verification"] = verif
        
        if not verif.get("safety_passed", True):
            feedback_record["security"]["status"] = "blocked"
            feedback_record["security"]["violations"].append(execution["error"])

        if execution.get("error") and "TimeoutError" in execution["error"]:
            feedback_record["execution"]["timeout"] = True

        # =================================================
        # EXECUTION FAILED
        # =================================================

        if not execution["success"]:
            error = execution["error"]
            category, specific_type, specific_msg = classify_error(error)
            
            attempt_record["execution_status"] = "failed"
            attempt_record["error_type"] = specific_type
            attempt_record["error_message"] = specific_msg

            # Retrieve Memory
            if config.get("MEMORY_ENABLED"):
                memories = repair_memory.search_similar_experiences(req.prompt, specific_type, specific_msg, current_code)
            else:
                memories = []
            memory_context = ""
            attempt_record["memory_used"] = len(memories) > 0
            attempt_record["retrieved_memory_count"] = len(memories)
            attempt_record["retrieved_memories"] = [{"memory_id": m["memory"]["memory_id"], "similarity": m["similarity"]} for m in memories]
            
            # --- STRATEGY LEARNING ---
            prev_strats = [att.get("strategy", {}).get("selected_strategy") for att in feedback_record["attempts"] if att.get("strategy")]
            diff_info = estimate_difficulty(specific_type, current_code, attempt + 1, len(memories) > 0)
            attempt_record["difficulty"] = diff_info
            
            strat_info = strategy_selector.select_strategy(
                error_type=specific_type,
                attempt_number=attempt + 1,
                previous_strategies=prev_strats,
                memory_available=len(memories) > 0,
                difficulty=diff_info["difficulty"]
            )
            attempt_record["strategy"] = strat_info
            
            # Strategy decides if we use memory in prompt
            if strat_info["selected_strategy"] == "DIRECT_REPAIR" or strat_info["selected_strategy"] == "MINIMAL_PATCH":
                memory_context = "" # Skip memory
            else:
                if memories:
                    for idx, m in enumerate(memories):
                        memory_context += f"Experience {idx+1}:\nError:\n{m['memory']['error_message']}\nBroken Code:\n{m['memory']['broken_code']}\nSuccessful Fix:\n{m['memory']['successful_fix']}\n\n"

            attempt_record["memory_injected"] = len(memory_context) > 0
            
            attempt_history.append({
                "attempt": attempt + 1,
                "stage": "execution",
                "error_type": specific_type,
                "error": error
            })
            feedback_record["attempts"].append(attempt_record)

            print("\nExecution Failed:")
            print(error)

            # =============================================
            # FIX CODE WITH TASK CONTRACT & HISTORY
            # =============================================
            strat_prompt = get_strategy_prompt(strat_info["selected_strategy"])
            fixed_code, debug_prompt = fix_code(
                current_code, error, memory_context,
                strategy_prompt=strat_prompt,
                task_contract=contract,
                attempt_history=attempt_history
            )
            attempt_record["debug_prompt"] = debug_prompt
            attempt_record["repair_applied"] = fixed_code
            
            # Explicit failure handling and identical state detection
            if not fixed_code or not fixed_code.strip():
                attempt_record["repair_generation_failed"] = True
                attempt_record["repair_failure_reason"] = "Model failed to produce valid Python code"
                attempt_record["repair_changed_code"] = False
            else:
                attempt_record["repair_generation_failed"] = False
                attempt_record["repair_failure_reason"] = None
                attempt_record["repair_changed_code"] = (fixed_code.strip() != current_code.strip())
                current_code = fixed_code
                
            feedback_record["total_repairs"] += 1
            if attempt + 1 >= MAX_RETRIES:
                print(f"\nMax retries exhausted ({MAX_RETRIES} attempts).")
                break
            continue
            
        attempt_record["execution_status"] = "success"
        feedback_record["verification"]["execution_passed"] = True
        feedback_record["verification"]["syntax_passed"] = True
        feedback_record["verification"]["safety_passed"] = True
        feedback_record["execution"]["status"] = "success"

        # =================================================
        # RUN TESTS (CONSTRAINED BY TASK CONTRACT)
        # =================================================

        tests = run_tests(
            req.prompt,
            current_code,
            authoritative_tests=contract.authoritative_tests,
            contract=contract
        )
        attempt_record["tests_generated"] = tests.get("tests", "")
        attempt_record["test_results"] = tests.get("test_summary", {})

        # Track Best Candidate
        t_summary = tests.get("test_summary", {})
        t_passed = t_summary.get("passed", 0)
        t_total = t_summary.get("total", 0)
        if contract_valid and t_passed > best_candidate["tests_passed"]:
            best_candidate = {
                "code": current_code,
                "tests_passed": t_passed,
                "total_tests": t_total,
                "contract_valid": True,
                "execution_passed": True
            }

        # =================================================
        # VERIFY ACCEPTANCE (TESTS + TASK CONTRACT)
        # =================================================

        # Re-verify contract on candidate before accepting
        final_contract_valid, final_contract_err = validate_code_against_contract(current_code, contract)

        failure_type = tests.get("failure_type")
        acceptance_passed = (
            contract is not None
            and bool(contract.entry_point)
            and final_contract_valid
            and tests.get("success", False)
            and failure_type is None
        )

        if acceptance_passed:
            feedback_record["attempts"].append(attempt_record)
            feedback_record["final_code"] = current_code
            feedback_record["final_status"] = "success"
            feedback_record["verification"]["tests_passed"] = True
            feedback_record["execution_time"] = time.time() - start_time
            best_candidate["code"] = current_code
            best_candidate["contract_valid"] = True
            
            # Store valid repairs in memory only if all verification passes
            if config.get("MEMORY_ENABLED") and feedback_record["verification"]["syntax_passed"] and feedback_record["verification"]["safety_passed"] and feedback_record["verification"]["execution_passed"] and feedback_record["verification"]["tests_passed"]:
                memories_added = False
                if len(feedback_record["attempts"]) > 1:
                    last_failed_att = feedback_record["attempts"][-2]
                    successful_att = feedback_record["attempts"][-1]
                    if last_failed_att.get("error_message") and last_failed_att.get("repair_applied"):
                        # Do not store security failures as successful repair memories
                        if "SecurityViolation" not in (last_failed_att.get("error_type") or ""):
                            added = repair_memory.add_repair_experience(
                                task=req.prompt,
                                error_type=last_failed_att["error_type"],
                                error_message=last_failed_att["error_message"],
                                broken_code=last_failed_att["code"],
                                successful_fix=last_failed_att["repair_applied"],
                                tests=successful_att["tests_generated"],
                                verification=feedback_record["verification"],
                                repair_attempts=1
                            )
                            if added:
                                memories_added = True
                            
                if config.get("LORA_ENABLED") and memories_added:
                    # Trigger controlled continual-learning training pipeline
                    try:
                        from app.train_worker import run_training_pipeline
                        train_res = run_training_pipeline(
                            force=False,
                            experiment_id=req.experiment_id,
                            trigger_task_id=getattr(req, "task_id", None),
                            trigger_task_index=getattr(req, "task_index", None)
                        )
                        if train_res.get("trained"):
                            feedback_record["training_triggered"] = True
                            feedback_record["training_cycle_id"] = train_res.get("training_cycle_id")
                            if train_res.get("promotion_status") == "promoted" or (train_res.get("success") and not train_res.get("rollback")):
                                feedback_record["training_status"] = "success"
                                print(f"[MAIN] Successfully updated adapter to {train_res.get('adapter_id')}")
                                check_and_reload_adapter()
                                feedback_record["active_adapter_id"] = app_model._loaded_adapter_id
                            elif train_res.get("rollback"):
                                feedback_record["training_status"] = "rejected_rollback"
                                feedback_record["training_error"] = train_res.get("rejection_reason")
                                print(f"[MAIN WARNING] Candidate {train_res.get('adapter_id')} rejected by Canary Gate. Retaining stable adapter: {train_res.get('active_adapter_id')}")
                                feedback_record["active_adapter_id"] = app_model._loaded_adapter_id
                            else:
                                feedback_record["training_status"] = "failed"
                                print(f"[MAIN ERROR] Training cycle failed: {train_res.get('error')}")
                                feedback_record["training_error"] = train_res.get("error")
                    except Exception as train_exc:
                        print(f"[MAIN ERROR] Unexpected error during training pipeline execution: {train_exc}")
                        feedback_record["training_error"] = str(train_exc)
                        feedback_record["training_triggered"] = True
                        feedback_record["training_status"] = "failed"
            
            record_strategy_outcomes(feedback_record)
            save_feedback(feedback_record, experiment_id=req.experiment_id)

            return {
                "success": True,
                "code": current_code,
                "attempts_used": attempt + 1,
                "generated_code": current_code,
                "execution": execution,
                "tests": tests,
                "history": attempt_history,
                "feedback_record": feedback_record
            }

        # =================================================
        # TEST OR CONTRACT FAILURE
        # =================================================

        if not final_contract_valid:
            failure_type = "CONTRACT_FAILURE"
            error = final_contract_err
            specific_type = "ContractViolation"
            specific_msg = final_contract_err
        elif failure_type in ("TEST_HARNESS_FAILURE", "TEST_ORACLE_FAILURE", "TEST_GENERATION_FAILURE", "ORACLE_UNDETERMINED"):
            error = tests.get("message", "Test harness/oracle failure")
            specific_type = failure_type
            specific_msg = error
        else:
            failure_type = "CODE_FAILURE"
            error = tests.get("message", "Test Failed")
            category, specific_type, specific_msg = classify_error(error)
        
        attempt_record["failure_type"] = failure_type
        attempt_record["error_type"] = specific_type
        attempt_record["error_message"] = specific_msg

        # Diagnostic logging of complete state trace
        cand_syntax_state = "VALID"
        try:
            ast.parse(current_code)
        except Exception as e_syn:
            cand_syntax_state = f"SYNTAX_ERROR ({e_syn})"

        test_code_str = tests.get("tests", "")
        test_syntax_state = "VALID"
        if test_code_str:
            try:
                ast.parse(test_code_str)
            except Exception as e_tsyn:
                test_syntax_state = f"SYNTAX_ERROR ({e_tsyn})"
        else:
            test_syntax_state = "EMPTY"

        test_harness_state = "VALID" if failure_type != "TEST_HARNESS_FAILURE" else f"HARNESS_ERROR ({error})"
        oracle_state = "VALID"
        if failure_type == "TEST_ORACLE_FAILURE":
            oracle_state = f"CONTRADICTORY ({error})"
        elif failure_type == "ORACLE_UNDETERMINED":
            oracle_state = "UNDETERMINED"
        elif failure_type == "TEST_GENERATION_FAILURE":
            oracle_state = "GENERATION_FAILURE"

        exec_state = "SUCCESS" if execution.get("success") else f"FAILED ({execution.get('error')})"
        contract_state = "VALID" if final_contract_valid else f"VIOLATION ({final_contract_err})"

        will_repair = failure_type not in ("TEST_HARNESS_FAILURE", "TEST_ORACLE_FAILURE", "TEST_GENERATION_FAILURE", "ORACLE_UNDETERMINED")
        repair_decision = "fix_code() TRIGGERED" if will_repair else f"ISOLATED ({failure_type}: Candidate protected from bad oracle/harness)"

        print("\n--- [DIAGNOSTIC PIPELINE STATE TRACE] ---")
        print(f"Candidate syntax state : {cand_syntax_state}")
        print(f"Test syntax state      : {test_syntax_state}")
        print(f"Test-harness state     : {test_harness_state}")
        print(f"Oracle state           : {oracle_state}")
        print(f"Execution state        : {exec_state}")
        print(f"Contract state         : {contract_state}")
        print(f"Final FailureType      : {failure_type}")
        print(f"Fix_code() called      : {will_repair}")
        print(f"Repair decision reason : {repair_decision}")
        print("-----------------------------------------\n")

        # =========================================================
        # HARNESS / ORACLE / GENERATION ISOLATION (Requirements E & H)
        # =========================================================
        # If failure is in test harness, test oracle, or test generation:
        # DO NOT call fix_code() on the candidate code!
        # Do NOT count it as code repair!
        # Preserve candidate code!
        if failure_type in ("TEST_HARNESS_FAILURE", "TEST_ORACLE_FAILURE", "TEST_GENERATION_FAILURE", "ORACLE_UNDETERMINED"):
            print(f"\n[{failure_type}] Discarding invalid test oracle. Preserving candidate code without mutation.")
            attempt_record["repair_applied"] = None
            attempt_record["repair_changed_code"] = False
            feedback_record["attempts"].append(attempt_record)

            # Contract smoke test: check if entry point runs without runtime crash
            smoke_res = execute_code(current_code, contract=contract)
            if smoke_res.get("success") and final_contract_valid:
                print(f"[SMOKE TEST SUCCESS] Candidate code safely executed contract entry point '{contract.entry_point}'.")
                best_candidate["code"] = current_code
                best_candidate["contract_valid"] = True
                best_candidate["execution_passed"] = True

            # Terminate repair evaluation cleanly on oracle/harness/generation failures
            print(f"[ISOLATION TERMINATE] Exiting repair loop cleanly due to {failure_type}.")
            break

        # Genuine CODE_FAILURE or CONTRACT_FAILURE: log to cumulative attempt history
        attempt_history.append({
            "attempt": attempt + 1,
            "stage": "testing" if final_contract_valid else "contract",
            "failure_type": failure_type,
            "error_type": specific_type,
            "error": error,
            "failing_test": tests.get("failing_test", "")
        })
        feedback_record["attempts"].append(attempt_record)

        print("\nValidation / Tests Failed:")
        print(error)

        # Retrieve Memory
        if config.get("MEMORY_ENABLED"):
            memories = repair_memory.search_similar_experiences(req.prompt, specific_type, specific_msg, current_code)
        else:
            memories = []
        memory_context = ""
        attempt_record["memory_used"] = len(memories) > 0
        attempt_record["retrieved_memory_count"] = len(memories)
        attempt_record["retrieved_memories"] = [{"memory_id": m["memory"]["memory_id"], "similarity": m["similarity"]} for m in memories]
        
        # --- STRATEGY LEARNING ---
        prev_strats = [att.get("strategy", {}).get("selected_strategy") for att in feedback_record["attempts"] if att.get("strategy")]
        diff_info = estimate_difficulty(specific_type, current_code, attempt + 1, len(memories) > 0)
        attempt_record["difficulty"] = diff_info
        
        strat_info = strategy_selector.select_strategy(
            error_type=specific_type,
            attempt_number=attempt + 1,
            previous_strategies=prev_strats,
            memory_available=len(memories) > 0,
            difficulty=diff_info["difficulty"]
        )
        attempt_record["strategy"] = strat_info
        
        if strat_info["selected_strategy"] == "DIRECT_REPAIR" or strat_info["selected_strategy"] == "MINIMAL_PATCH":
            memory_context = "" # Skip memory
        else:
            if memories:
                for idx, m in enumerate(memories):
                    memory_context += f"Experience {idx+1}:\nError:\n{m['memory']['error_message']}\nBroken Code:\n{m['memory']['broken_code']}\nSuccessful Fix:\n{m['memory']['successful_fix']}\n\n"

        attempt_record["memory_injected"] = len(memory_context) > 0

        # =================================================
        # FIX CODE WITH TASK CONTRACT & HISTORY
        # =================================================

        strat_prompt = get_strategy_prompt(strat_info["selected_strategy"])
        fixed_code, debug_prompt = fix_code(
            current_code, error, memory_context,
            strategy_prompt=strat_prompt,
            task_contract=contract,
            attempt_history=attempt_history
        )
        attempt_record["debug_prompt"] = debug_prompt
        attempt_record["repair_applied"] = fixed_code
        
        # Explicit failure handling and regression detection
        if not fixed_code or not fixed_code.strip():
            attempt_record["repair_generation_failed"] = True
            attempt_record["repair_failure_reason"] = "Model failed to produce valid Python code"
            attempt_record["repair_changed_code"] = False
        else:
            attempt_record["repair_generation_failed"] = False
            attempt_record["repair_failure_reason"] = None
            attempt_record["repair_changed_code"] = (fixed_code.strip() != current_code.strip())
            
            # Regression protection check
            fixed_contract_valid, _ = validate_code_against_contract(fixed_code, contract)
            if contract_valid and not fixed_contract_valid:
                attempt_record["regression_detected"] = True
                print(f"[REGRESSION WARNING] Repair attempt discarded required contract '{contract.entry_point}'.")
            
            current_code = fixed_code
            
        feedback_record["total_repairs"] += 1
        
        if attempt + 1 >= MAX_RETRIES:
            print(f"\nMax retries exhausted ({MAX_RETRIES} attempts).")
            break

    # =====================================================
    # MAX RETRIES EXCEEDED (REGRESSION ROLLBACK GUARD)
    # =====================================================

    # If current code regressed and broke contract, roll back to best known valid candidate
    if best_candidate["code"] is not None and best_candidate["contract_valid"]:
        cur_valid, _ = validate_code_against_contract(current_code, contract)
        if not cur_valid:
            print(f"\n[REGRESSION ROLLBACK] Restoring best known valid candidate ({best_candidate['tests_passed']}/{best_candidate['total_tests']} tests passed).")
            current_code = best_candidate["code"]

    feedback_record["final_code"] = current_code
    feedback_record["best_candidate"] = best_candidate
    feedback_record["final_status"] = "failure"
    feedback_record["execution_time"] = time.time() - start_time
    
    record_strategy_outcomes(feedback_record)
    save_feedback(feedback_record, experiment_id=req.experiment_id)

    return {
        "success": False,
        "code": current_code,
        "message": "Maximum retry attempts exceeded",
        "final_code": current_code,
        "history": attempt_history,
        "feedback_record": feedback_record
    }